# csc492bio
require R wgcna support

run :
./run.sh 
