#!/bin/bash
cd networkSrc
path=$1

cd wgcna
godie=$(Rscript wgcnaworking.R  $path $2|grep "this is the line")
echo $godie |cut -c 6-|rev|cut -c 2- |rev >$path/config
if ($2 -eq 0)
then
	exit
fi
cd ..
cp begin.html $path/begin.html
cp end.html $path/end.html
cp cytoscape.min.js $path/cytoscape.min.js
cp cy-style.json $path/cy-style.json
cp style.css $path/style.css


n=1
cat $path/begin.html>$path/index.html
while read node b color
do
    if (( $n >0 ))
    then
        n=0
        continue
    fi
    echo '{"data": {"id":"'$node'","type" : "'$color'"} },'>>$path/index.html
    #echo "{$path/data: {id:'"$node"',type : '"$color"'} },">>result.html
done < $path/CytoscapeInput-nodes-testData_threshold.out.txt
n=1
while read nodefrom nodeto weight e f
do
    if (( $n >0 ))
    then
        n=0
        continue
    fi
    #echo "{$path/data: {id:'"$nodefrom$nodeto"',source : '"$nodefrom"',target:'"$nodeto"','weight':"$weight"} },">>result.html
    echo '{"data": {"id":"'$nodefrom$nodeto'","source" : "'$nodefrom'","target":"'$nodeto'","weight":'$weight'} },'>>$path/index.html
done < $path/CytoscapeInput-edges-testData_threshold.out.txt
sed -i '$ s/.$//' $path/index.html
echo "]});">>$path/index.html
#while read node colon  shapeset
#do
#    echo "cy.getElementById('$node').data'set','$shapeset');">>result.html
#done < $path/../bar.txt
cat $path/end.html >> $path/index.html
