myDir=$1
echo $myDir
