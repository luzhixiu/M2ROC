sudo apt-get install python
sudo apt-get install python-pip
sudo apt-get install python-flask
pip install configparser
pip install scipy
sudo apt-get install python-scipy
   
pip install matplotlib

sudo apt-get install python-tk

pip install sklearn


